package com.example.foret_app_prototype.activity.free;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.foret_app_prototype.R;

public class EditFreeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_free);
    }
}