package com.example.foret_app_prototype.activity.search;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.foret_app_prototype.R;

public class SearchResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_result);
    }
}