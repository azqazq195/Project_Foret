package com.example.foret_app_prototype.model;

public class HomeDTO {
    int id;
    private String name;
    private String introduce;
    private String photo;

}
