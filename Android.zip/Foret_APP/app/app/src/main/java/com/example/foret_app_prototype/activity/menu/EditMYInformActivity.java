package com.example.foret_app_prototype.activity.menu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.foret_app_prototype.R;

public class EditMYInformActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_m_y_inform);
    }
}