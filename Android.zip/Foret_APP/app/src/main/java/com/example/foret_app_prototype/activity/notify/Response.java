package com.example.foret_app_prototype.activity.notify;

public class Response {
    private String success;

}
