package com.example.foret_app_prototype.response;

public class CommentListResponse {
}
