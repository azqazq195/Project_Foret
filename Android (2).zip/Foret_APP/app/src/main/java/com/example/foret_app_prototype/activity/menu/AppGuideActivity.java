package com.example.foret_app_prototype.activity.menu;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.foret_app_prototype.R;

public class AppGuideActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_guide);
    }
}